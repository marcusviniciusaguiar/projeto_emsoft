Esta aplicação web tem como objetivo o salvamento de dados em um arquivo .json em formato JSON.
Para pleno funcionamento desta, é necessário que a pasta do projeto esteja em execução em um servidor capaz de interpretar o PHP na versão 8.2.12 (Versão utilizada na aplicação),
após isso, o usuário deve acessar o arquivo através do servidor utilizado para executá-lo, e assim poderá utilizar a aplicação.
Modelo de acesso aos arquivos:
Via localhost: http://localhost/projeto/
Via IP Local: http://IP_LOCAL/projeto/ - ex: http://192.168.1.10/projeto/
Via IP Externo: http://IP_PUBLICO/projeto/ ex: http://177.200.15.88/projeto/ (Caso a porta exposta seja 80 ou redirecionada para 80)
Via DDNS: http://seusite.ddns.net/projeto/ (Porta 80)

Neste projeto foram usadas as seguintes ferramentas:
PHP 8.2.12
JavaScript
HTML5
CSS3